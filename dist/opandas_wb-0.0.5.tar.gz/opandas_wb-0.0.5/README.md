# CPSProject - Operation P.A.N.D.A.S.



Home del Package su TestPyPI: 

[https://test.pypi.org/project/opandas-wb/0.0.3/](https://test.pypi.org/project/opandas-wb/0.0.3/)

Installazione del package 

    python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps opandas_wb

Importare il package 

    from opandas_wb import *
